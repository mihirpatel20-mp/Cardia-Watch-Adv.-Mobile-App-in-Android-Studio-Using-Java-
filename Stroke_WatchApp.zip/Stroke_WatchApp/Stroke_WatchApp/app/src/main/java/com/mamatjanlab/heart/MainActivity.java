package com.mamatjanlab.heart;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity implements SensorEventListener {

    private static final int REQUEST_BODY_SENSORS_PERMISSION = 1;
    private SensorManager sensorManager;
    private Sensor heartRateSensor;
    private TextView heartRateValue;
    private int heartRateInt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize sensor manager and sensors
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        heartRateValue = findViewById(R.id.heart_rate_value);

        // Get sensor list for debugging purposes
        List<Sensor> sensorList = sensorManager.getSensorList(Sensor.TYPE_ALL);
        Log.d("myTag", sensorList.toString());

        // Request body sensor permission if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BODY_SENSORS},
                    REQUEST_BODY_SENSORS_PERMISSION);
        } else {
            // Permission already granted, register heart rate sensor listener
            heartRateSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
            sensorManager.registerListener(this, heartRateSensor, SensorManager.SENSOR_DELAY_FASTEST);
        }

        // Upload button click listener
        Button uploadButton = findViewById(R.id.upload_button);
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (heartRateValue != null) {
                    // Get heart rate value from TextView
                    String heartRateText = heartRateValue.getText().toString();

                    // Get systolic pressure value from EditText
                    EditText systolicPressureEditText = findViewById(R.id.blood_pressure_systolic);
                    int systolicPressure = Integer.parseInt(systolicPressureEditText.getText().toString());

                    // Get diastolic pressure value from EditText
                    EditText diastolicPressureEditText = findViewById(R.id.blood_pressure_diastolic);
                    int diastolicPressure = Integer.parseInt(diastolicPressureEditText.getText().toString());

                    // Create upload string
                    String uploadString = "Heart Rate: " + heartRateText + ", Systolic Pressure: " + systolicPressure + ", Diastolic Pressure: " + diastolicPressure;
                    Log.d("Upload", uploadString);

                    // Execute AsyncTask to upload data
                    AsyncTask<Void, Void, Integer> asyncTask = new AsyncTask<Void, Void, Integer>() {
                        @Override
                        protected Integer doInBackground(Void... voids) {
                            try {
                                // Create connection and set request properties
                                URL url = new URL("https://api.airtable.com/v0/apprnAsXyMdDIGjbb/tblvSQoYC0c19Ck0D");
                                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                                conn.setRequestMethod("POST");
                                conn.setRequestProperty("Content-Type", "application/json");
                                conn.setRequestProperty("Authorization", "Bearer pat1f92mtJbaRMDsJ.e43ffd20bdcf4f72aca077c6d5c3f79176584ca26e572c5834d3691800951891");
                                conn.setDoOutput(true);

                                // Create timestamp in the desired format
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
                                String timestamp = sdf.format(new Date());

                                // Create JSON data string
                                String jsonHRData = "{\"fields\": {\"username\": \"username\", \"password\": \"password\", \"systolic\": " + systolicPressure + ", \"diastolic\": " + diastolicPressure + ", \"bpm\": " + heartRateInt + ", \"timestamp\": \"" + timestamp + "\"}}";

                                // Write JSON data to output stream
                                OutputStream outputStream = conn.getOutputStream();
                                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                                writer.write(jsonHRData);
                                writer.flush();
                                writer.close();
                                outputStream.close();

                                // Get response code
                                int responseCode = conn.getResponseCode();
                                conn.disconnect();
                                return responseCode;
                            } catch (Exception e) {
                                e.printStackTrace();
                                return -1;
                            }
                        }

                        @Override
                        protected void onPostExecute(Integer responseCode) {
                            if (responseCode == HttpURLConnection.HTTP_OK) {
                                Log.d("Response", "uploaded");

                                Toast.makeText(MainActivity.this, "Uploaded", Toast.LENGTH_SHORT).show();
                            } else {
                                Log.d("Response", "error, not uploaded: " + responseCode);
                            }
                        }
                    };

                    asyncTask.execute();
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BODY_SENSORS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, register sensor listeners
                heartRateSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
                sensorManager.registerListener(this, heartRateSensor, SensorManager.SENSOR_DELAY_FASTEST);
            } else {
                // Permission not granted, handle the error or show a message to the user
            }
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() == Sensor.TYPE_HEART_RATE && event.values[0] != 0.0f) {
            // Update heart rate value when sensor data changes and the value is not 0
            float heartRate = event.values[0];
            heartRateInt = (int) heartRate;
            heartRateValue.setText("Live HR: " + heartRateInt);
        }
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (heartRateSensor != null && ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS) == PackageManager.PERMISSION_GRANTED) {
            // Register heart rate sensor listener when resuming the activity
            sensorManager.registerListener(this, heartRateSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister sensor listener when pausing the activity
        sensorManager.unregisterListener(this);
    }
}