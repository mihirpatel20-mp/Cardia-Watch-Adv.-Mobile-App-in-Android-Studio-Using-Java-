package com.example.cardiawatch;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextPassword;
    private DatabaseHelper dbHelper;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        editTextEmail = findViewById(R.id.editTextLoginEmail);
        editTextPassword = findViewById(R.id.editTextLoginPassword);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playMusic();
                String email = editTextEmail.getText().toString().trim();
                String password = editTextPassword.getText().toString().trim();

                if (!email.isEmpty() && !password.isEmpty()) {
                    login(email, password);
                } else {
                    Toast.makeText(LoginActivity.this,
                            "Please enter both email and password",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        mediaPlayer = MediaPlayer.create(this, R.raw.music); // Assuming music.mp3 is in the raw folder
    }

    private void playMusic() {
        if (mediaPlayer != null) {
            mediaPlayer.start();
        }
    }

    private void login(String email, String password) {
        boolean isUserExists = dbHelper.checkUser(email, password);
        if (isUserExists) {
            Toast.makeText(LoginActivity.this,
                    "Login successful", Toast.LENGTH_SHORT).show();
            // Redirect to HomeActivity after successful login
            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // Close LoginActivity
        } else {
            Toast.makeText(LoginActivity.this,
                    "Login failed. Invalid credentials.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
