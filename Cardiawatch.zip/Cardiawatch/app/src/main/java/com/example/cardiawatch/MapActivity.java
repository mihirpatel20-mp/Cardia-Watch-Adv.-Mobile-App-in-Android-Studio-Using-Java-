package com.example.cardiawatch;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        Objects.requireNonNull(mapFragment).getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Kamloops, BC coordinates
        LatLng kamloops = new LatLng(50.6761, -120.3408);

        // Move the camera to Kamloops and set zoom level
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(kamloops, 12f));

        // Fetch hospital/clinic data from an API
        new FetchPlacesTask().execute();
    }

    private class FetchPlacesTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // Replace "YOUR_API_KEY" with your actual API key
                String apiKey = "AIzaSyBCFN1jX3qrNWB0zrDaWE09_WdceT2N0V8";
                URL url = new URL("https://maps.googleapis.com/maps/api/place/nearbysearch/json?" +
                        "location=50.6761,-120.3408" + // Kamloops coordinates
                        "&radius=5000" + // Within 5km radius
                        "&types=hospital" + // Fetch only hospitals
                        "&key=" + apiKey); // Replace with your API key

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                StringBuilder response = new StringBuilder();
                InputStreamReader inputStreamReader = new InputStreamReader(connection.getInputStream());
                BufferedReader reader = new BufferedReader(inputStreamReader);

                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                return response.toString();
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String jsonString) {
            if (jsonString != null) {
                addMarkersToMap(jsonString);
            } else {
                Toast.makeText(MapActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addMarkersToMap(String jsonString) {
        try {
            JSONObject jsonObject = new JSONObject(jsonString);
            JSONArray resultsArray = jsonObject.getJSONArray("results");

            for (int i = 0; i < resultsArray.length(); i++) {
                JSONObject place = resultsArray.getJSONObject(i);
                JSONObject location = place.getJSONObject("geometry").getJSONObject("location");
                String name = place.getString("name");
                double lat = location.getDouble("lat");
                double lng = location.getDouble("lng");

                LatLng hospitalLatLng = new LatLng(lat, lng);
                mMap.addMarker(new MarkerOptions().position(hospitalLatLng).title(name));
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error parsing data", Toast.LENGTH_SHORT).show();
        }
    }
}
