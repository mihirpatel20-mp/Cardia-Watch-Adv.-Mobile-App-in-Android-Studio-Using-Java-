package com.example.cardiawatch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    private EditText editTextName, editTextSystolicPressure, editTextDiastolicPressure,
            editTextSmoking, editTextHeight, editTextWeight, editTextCholesterol,
            editTextTOS, editTextMRS;
    private Button buttonCreateProfile;

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        editTextName = findViewById(R.id.editTextName);
        editTextSystolicPressure = findViewById(R.id.editTextSystolicPressure);
        editTextDiastolicPressure = findViewById(R.id.editTextDiastolicPressure);
        editTextSmoking = findViewById(R.id.editTextSmoking);
        editTextHeight = findViewById(R.id.editTextHeight);
        editTextWeight = findViewById(R.id.editTextWeight);
        editTextCholesterol = findViewById(R.id.editTextCholesterol);
        editTextTOS = findViewById(R.id.editTextTOS);
        editTextMRS = findViewById(R.id.editTextMRS);
        buttonCreateProfile = findViewById(R.id.buttonCreateProfile);

        buttonCreateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDataToDatabase();
            }
        });

        mediaPlayer = MediaPlayer.create(this, R.raw.music);

        buttonCreateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDataToDatabase();
                playMusic();
            }
        });


    }

    private void saveDataToDatabase() {
        String name = editTextName.getText().toString().trim();
        String systolicPressure = editTextSystolicPressure.getText().toString().trim();
        String diastolicPressure = editTextDiastolicPressure.getText().toString().trim();
        String smoking = editTextSmoking.getText().toString().trim();
        String height = editTextHeight.getText().toString().trim();
        String weight = editTextWeight.getText().toString().trim();
        String cholesterol = editTextCholesterol.getText().toString().trim();
        String tos = editTextTOS.getText().toString().trim();
        String mrs = editTextMRS.getText().toString().trim();


        DatabaseHelper2 dbHelper2 = new DatabaseHelper2(this);
        boolean isInserted = dbHelper2.addUserData(name, systolicPressure, diastolicPressure,
                smoking, height, weight, cholesterol, tos, mrs);

        if (isInserted) {
            Toast.makeText(this, "Data saved to database", Toast.LENGTH_SHORT).show();
            // Optionally, clear the EditText fields after saving
            clearEditTextFields();

            // Fetch the recently saved user ID from the database or use a generated one
            int userId = dbHelper2.getMaxUserId();

            // Start UpdateAndDeleteActivity with the recently saved data
            navigateToUpdateAndDeleteActivity(userId);
        } else {
            Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show();
        }
    }


    private void playMusic() {
        if (mediaPlayer != null) {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start(); // Start playing the music
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release the media player resources when the activity is destroyed
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void clearEditTextFields() {
        editTextName.setText("");
        editTextSystolicPressure.setText("");
        editTextDiastolicPressure.setText("");
        editTextSmoking.setText("");
        editTextHeight.setText("");
        editTextWeight.setText("");
        editTextCholesterol.setText("");
        editTextTOS.setText("");
        editTextMRS.setText("");
    }

    private void navigateToUpdateAndDeleteActivity(int userId) {
        Intent intent = new Intent(HomeActivity.this, UpdateAndDeleteActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        // Optionally, finish the current activity if needed
        //finish();
    }
}
