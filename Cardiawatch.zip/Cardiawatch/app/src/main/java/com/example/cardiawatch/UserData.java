import java.io.Serializable;

public class UserData implements Serializable {
    private int id; // Modify this to match the id type in your database
    private String name;
    private String systolicPressure;
    private String diastolicPressure;
    private String smoking;
    private String height;
    private String weight;
    private String cholesterol;
    private String tos;
    private String mrs;

    public UserData(int id, String name, String systolicPressure, String diastolicPressure,
                    String smoking, String height, String weight, String cholesterol,
                    String tos, String mrs) {
        this.id = id;
        this.name = name;
        this.systolicPressure = systolicPressure;
        this.diastolicPressure = diastolicPressure;
        this.smoking = smoking;
        this.height = height;
        this.weight = weight;
        this.cholesterol = cholesterol;
        this.tos = tos;
        this.mrs = mrs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSystolicPressure() {
        return systolicPressure;
    }

    public void setSystolicPressure(String systolicPressure) {
        this.systolicPressure = systolicPressure;
    }

    public String getDiastolicPressure() {
        return diastolicPressure;
    }

    public void setDiastolicPressure(String diastolicPressure) {
        this.diastolicPressure = diastolicPressure;
    }

    public String getSmoking() {
        return smoking;
    }

    public void setSmoking(String smoking) {
        this.smoking = smoking;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getCholesterol() {
        return cholesterol;
    }

    public void setCholesterol(String cholesterol) {
        this.cholesterol = cholesterol;
    }

    public String getTos() {
        return tos;
    }

    public void setTos(String tos) {
        this.tos = tos;
    }

    public String getMrs() {
        return mrs;
    }

    public void setMrs(String mrs) {
        this.mrs = mrs;
    }
}
