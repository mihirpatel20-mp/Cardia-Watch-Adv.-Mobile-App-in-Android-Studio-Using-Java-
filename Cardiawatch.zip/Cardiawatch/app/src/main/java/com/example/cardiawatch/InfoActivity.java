package com.example.cardiawatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        InfoAdapter adapter = new InfoAdapter(getInfoData());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    // Function to provide data for each view
    private ArrayList<InfoItem> getInfoData() {
        ArrayList<InfoItem> data = new ArrayList<>();
        // Add your 14 different views with descriptions here
        data.add(new InfoItem("What health conditions increase the risk of heart disease?", "High blood pressure is a major risk factor for heart disease. It is a medical condition that happens when the pressure of the blood in your arteries and other blood vessels is too high. The high pressure, if not controlled, can affect your heart and other major organs of your body, including your kidneys and brain.\n" +
                "\n" +
                "High blood pressure is often called a “silent killer” because it usually has no symptoms. The only way to know whether you have high blood pressure is to measure your blood pressure. You can lower your blood pressure with lifestyle changes or with medicine to reduce your risk for heart disease and heart attack. Learn more about blood pressure. Your body needs glucose (sugar) for energy. Insulin is a hormone made in the pancreas that helps move glucose from the food you eat to your body’s cells for energy. If you have diabetes, your body doesn’t make enough insulin, can’t use its own insulin as well as it should, or both.\n" +
                "\n" +
                "Diabetes causes sugar to build up in the blood. The risk of death from heart disease for adults with diabetes is higher than for adults who do not have diabetes.2 Talk with your doctor about ways to prevent or manage diabetes and control other risk factors.\n" +
                "\n" +
                "Obesity. Obesity is excess body fat. Obesity is linked to higher “bad” cholesterol and triglyceride levels and to lower “good” cholesterol levels. Obesity can lead to high blood pressure and diabetes as well as heart disease. Talk with your health care team about a plan to reduce your weight to a healthy level. Learn more about healthy weight.", R.drawable.icon1));
        data.add(new InfoItem("Does Unhealthy blood cholestrol levels increase the risk of heart disease?", "Unhealthy blood cholesterol levels. Cholesterol is a waxy, fat-like substance made by the liver or found in certain foods. Your liver makes enough for your body’s needs, but we often get more cholesterol from the foods we eat.\n" +
                "\n" +
                "If we take in more cholesterol than the body can use, the extra cholesterol can build up in the walls of the arteries, including those of the heart. This leads to narrowing of the arteries and can decrease the blood flow to the heart, brain, kidneys, and other parts of the body.\n" +
                "\n" +
                "There are two main types of blood cholesterol: LDL (low-density lipoprotein) cholesterol, which is considered to be “bad” cholesterol because it can cause plaque buildup in your arteries, and HDL (high-density lipoprotein) cholesterol, which is considered to be “good” cholesterol because higher levels provide some protection against heart disease.\n" +
                "\n" +
                "High blood cholesterol usually has no signs or symptoms. The only way to know whether you have high cholesterol is to get your cholesterol checked. Your health care team can do a simple blood test, called a “lipid profile,” to measure your cholesterol levels. Learn more about getting your cholesterol checked.\n" +
                "\n" +
                "", R.drawable.icon2));

        data.add(new InfoItem("What behaviors increase the risk of heart disease", "Your lifestyle can increase your risk for heart disease.\n" +
                "\n" +
                "Eating a diet high in saturated fats, trans fat, and cholesterol has been linked to heart disease and related conditions, such as atherosclerosis. Also, too much salt (sodium) in the diet can raise blood pressure.\n" +
                "Not getting enough physical activity can lead to heart disease. It can also increase the chances of having other medical conditions that are risk factors, including obesity, high blood pressure, high cholesterol, and diabetes. Regular physical activity can lower your risk for heart disease.\n" +
                "Drinking too much alcohol can raise blood pressure levels and the risk for heart disease. It also increases levels of triglycerides, a fatty substance in the blood which can increase the risk for heart disease.\n" +
                "Women should have no more than 1 drink a day.\n" +
                "Men should have no more than 2 drinks a day. \n" +
                "Tobacco use increases the risk for heart disease and heart attack:\n" +
                "Cigarette smoking can damage the heart and blood vessels, which increases your risk for heart conditions such as atherosclerosis and heart attack.\n" +
                "Nicotine raises blood pressure.\n" +
                "Carbon monoxide from cigarette smoke reduces the amount of oxygen that your blood can carry.\n" +
                "Exposure to secondhand smoke can also increase the risk for heart disease, even for nonsmokers.\n" +
                "\n" +
                "\n", R.drawable.icon3));
        data.add(new InfoItem("How do genetics and family history affect the risk of heart disease?", "When members of a family pass traits from one generation to another through genes, that process is called heredity.\n" +
                "\n" +
                "Genetic factors likely play some role in high blood pressure, heart disease, and other related conditions. However, it is also likely that people with a family history of heart disease share common environments and other factors that may increase their risk.\n" +
                "\n" +
                "The risk for heart disease can increase even more when heredity combines with unhealthy lifestyle choices, such as smoking cigarettes and eating an unhealthy diet.\n" +
                "\n" +
                "\n", R.drawable.icon4));
        data.add(new InfoItem("Do age and sex affect the risk of heart disease?", "Heart disease is the number one killer of both men and women. Heart disease can happen at any age, but the risk goes up as you age.\n" +
                "\n", R.drawable.icon5));
        data.add(new InfoItem("Do race and ethnicity affect the risk of heart disease?", "Heart disease and stroke can affect anyone, but some groups are more likely to have conditions that increase their risk for cardiovascular disease.\n" +
                "\n" +
                "Heart disease is the leading cause of death for people of most racial and ethnic groups in the United States, including African Americans, American Indians and Alaska Natives, and white people. For Asian Americans and Pacific Islanders and Hispanics, heart disease is second only to cancer.\n" +
                "\n" +
                "\n", R.drawable.icon6));

        data.add(new InfoItem("Can risk factors be changed?", "Some risk factors can be changed and some can’t. You may be born with certain risk factors that can’t be changed. Since you can’t do anything about these risk factors, it’s even more important to manage your risk factors that can be changed.\n" +
                "\n" +
                "\n", R.drawable.icon7));
        data.add(new InfoItem("Be a Team Player and Ask for Support", "A heart attack can occur at any age. You’re never too young to start living healthier. If you’re over 40, or if you have multiple risk factors, work closely with your health care team to address your risk of developing cardiovascular disease. A team-based approach is the best way to prevent heart disease and stroke. You and your health care team can build a prevention plan that works for you.\n" +
                "\n" +
                "If you’re prescribed medications to manage blood sugar, cholesterol, blood pressure or other conditions, take them as directed.\n" +
                "\n" +
                "Talk about challenges in your life that may affect your health and ask for support. If you have concerns about accessing care, affording your medications or finding transportation to and from medical appointments, ask your health care team about finding resources.\n" +
                "\n" +
                "You’re the most important member of your health care team. And they depend on you to tell them how you feel and what help you need. So ask questions and make decisions together.\n" +
                "\n" +
                "Together, you can reduce your risk of heart attack.\n" +
                "\n" +
                "\n", R.drawable.icon8));
        data.add(new InfoItem("Heart disease symptoms caused by congenital heart defects", "Serious congenital heart defects usually are noticed soon after birth. Congenital heart defect symptoms in children could include:\n" +
                "\n" +
                "Pale gray or blue skin or lips (cyanosis)\n" +
                "Swelling in the legs, belly area or areas around the eyes\n" +
                "In an infant, shortness of breath during feedings, leading to poor weight gain\n" +
                "Less-serious congenital heart defects are often not diagnosed until later in childhood or during adulthood. Symptoms of congenital heart defects that usually aren't immediately life-threatening include:\n" +
                "\n" +
                "Easily getting short of breath during exercise or activity\n" +
                "Easily tiring during exercise or activity\n" +
                "Swelling of the hands, ankles or feet\n" +
                "\n", R.drawable.icon9));
        data.add(new InfoItem("Heart disease symptoms caused by diseased heart muscle (cardiomyopathy)", "Early stages of cardiomyopathy may not cause noticeable symptoms. As the condition worsens, symptoms may include:\n" +
                "\n" +
                "Dizziness, lightheadedness and fainting\n" +
                "Fatigue\n" +
                "Feeling short of breath during activity or at rest\n" +
                "Feeling short of breath at night when trying to sleep or waking up short of breath\n" +
                "Irregular heartbeats that feel rapid, pounding or fluttering\n" +
                "Swollen legs, ankles or feet\n" +
                "\n" +
                "\n", R.drawable.icon10));
        data.add(new InfoItem("Heart disease symptoms caused by heart valve problems (valvular heart disease)", "The heart has four valves — the aortic, mitral, pulmonary and tricuspid valves. They open and close to move blood through the heart. Many things can damage the heart valves. A heart valve may become narrowed (stenosis), leaky (regurgitation or insufficiency) or close improperly (prolapse).\n" +
                "\n" +
                "Valvular heart disease is also called heart valve disease. Depending on which valve isn't working properly, heart valve disease symptoms generally include:\n" +
                "\n" +
                "Chest pain\n" +
                "Fainting (syncope)\n" +
                "Fatigue\n" +
                "Irregular heartbeat\n" +
                "Shortness of breath\n" +
                "Swollen feet or ankles\n" +
                "Endocarditis is an infection that affects the heart valves and inner lining of the heart chambers and heart valves (endocardium). Endocarditis symptoms can include:\n" +
                "\n" +
                "Dry or persistent cough\n" +
                "Fever\n" +
                "Heartbeat changes\n" +
                "Shortness of breath\n" +
                "Skin rashes or unusual spots\n" +
                "Swelling of the legs or belly area\n" +
                "Weakness or fatigue\n" +
                "\n" +
                "\n", R.drawable.icon11));







        // Add more items...

        return data;
    }
}
