package com.example.cardiawatch;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateAndDeleteActivity extends AppCompatActivity {

    private EditText editTextName, editTextSystolicPressure, editTextDiastolicPressure, editTextSmoking,
            editTextHeight, editTextWeight, editTextCholesterol, editTextTOS, editTextMRS;
    private Button buttonUpdate, buttonDelete, buttonInfo, buttonMap, buttonResult, buttonShowHistory; // Added button for InfoActivity
    private DatabaseHelper2 dbHelper2;
    private int userId;

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_and_delete);

        dbHelper2 = new DatabaseHelper2(this);

        userId = getIntent().getIntExtra("USER_ID", -1);

        editTextName = findViewById(R.id.editTextName);
        editTextSystolicPressure = findViewById(R.id.editTextSystolicPressure);
        editTextDiastolicPressure = findViewById(R.id.editTextDiastolicPressure);
        editTextSmoking = findViewById(R.id.editTextSmoking);
        editTextHeight = findViewById(R.id.editTextHeight);
        editTextWeight = findViewById(R.id.editTextWeight);
        editTextCholesterol = findViewById(R.id.editTextCholesterol);
        editTextTOS = findViewById(R.id.editTextTOS);
        editTextMRS = findViewById(R.id.editTextMRS);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonInfo = findViewById(R.id.buttonInfo); // Initialize Info button
        buttonMap = findViewById(R.id.buttonMap);

        mediaPlayer = MediaPlayer.create(this, R.raw.music);

        retrieveData();

        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateData();
                playMusic();
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData();
                playMusic();
            }
        });

        // On click listener for Info button
        buttonInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playMusic();
                // Start InfoActivity
                startActivity(new Intent(UpdateAndDeleteActivity.this, InfoActivity.class));
            }
        });

        buttonMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playMusic();
                // Start InfoActivity
                startActivity(new Intent(UpdateAndDeleteActivity.this, MapActivity.class));
            }
        });
    }




    private void retrieveData() {
        String[] userData = dbHelper2.fetchUserData(userId);

        if (userData != null) {
            editTextName.setText(userData[0]);
            editTextSystolicPressure.setText(userData[1]);
            editTextDiastolicPressure.setText(userData[2]);
            editTextSmoking.setText(userData[3]);
            editTextHeight.setText(userData[4]);
            editTextWeight.setText(userData[5]);
            editTextCholesterol.setText(userData[6]);
            editTextTOS.setText(userData[7]);
            editTextMRS.setText(userData[8]);
        } else {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateData() {
        String name = editTextName.getText().toString().trim();
        String systolicPressure = editTextSystolicPressure.getText().toString().trim();
        String diastolicPressure = editTextDiastolicPressure.getText().toString().trim();
        String smoking = editTextSmoking.getText().toString().trim();
        String height = editTextHeight.getText().toString().trim();
        String weight = editTextWeight.getText().toString().trim();
        String cholesterol = editTextCholesterol.getText().toString().trim();
        String tos = editTextTOS.getText().toString().trim();
        String mrs = editTextMRS.getText().toString().trim();

        boolean isUpdated = dbHelper2.updateUserData(userId, name, systolicPressure, diastolicPressure,
                smoking, height, weight, cholesterol, tos, mrs);

        if (isUpdated) {
            Toast.makeText(this, "Data updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to update data", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteData() {
        boolean isDeleted = dbHelper2.deleteUserData(userId);

        if (isDeleted) {
            Toast.makeText(this, "Data deleted successfully", Toast.LENGTH_SHORT).show();
            editTextName.setText("");
            editTextSystolicPressure.setText("");
            editTextDiastolicPressure.setText("");
            editTextSmoking.setText("");
            editTextHeight.setText("");
            editTextWeight.setText("");
            editTextCholesterol.setText("");
            editTextTOS.setText("");
            editTextMRS.setText("");
        } else {
            Toast.makeText(this, "Failed to delete data", Toast.LENGTH_SHORT).show();
        }
    }

    public void result(View view) {
            Intent intent = new Intent(this, ResultActivity.class);
            startActivity(intent);
    }


    public void watchhistory(View view) {
        Intent intent = new Intent(this, watchdata.class);
        startActivity(intent);
    }


    private void playMusic() {
        if (mediaPlayer != null) {
            if (!mediaPlayer.isPlaying()) {
                mediaPlayer.start(); // Start playing the music
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Release the media player resources when the activity is destroyed
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }


}
