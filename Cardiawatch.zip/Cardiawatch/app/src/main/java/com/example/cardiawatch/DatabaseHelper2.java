package com.example.cardiawatch;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper2 extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "HomeActivityDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USER_DATA = "user_data";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_SYSTOLIC_PRESSURE = "systolic_pressure";
    private static final String COLUMN_DIASTOLIC_PRESSURE = "diastolic_pressure";
    private static final String COLUMN_SMOKING = "smoking";
    private static final String COLUMN_HEIGHT = "height";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_CHOLESTEROL = "cholesterol";
    private static final String COLUMN_TOS = "tos";
    private static final String COLUMN_MRS = "mrs";

    public DatabaseHelper2(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USER_DATA_TABLE = "CREATE TABLE " + TABLE_USER_DATA +
                "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NAME + " TEXT," +
                COLUMN_SYSTOLIC_PRESSURE + " TEXT," +
                COLUMN_DIASTOLIC_PRESSURE + " TEXT," +
                COLUMN_SMOKING + " TEXT," +
                COLUMN_HEIGHT + " TEXT," +
                COLUMN_WEIGHT + " TEXT," +
                COLUMN_CHOLESTEROL + " TEXT," +
                COLUMN_TOS + " TEXT," +
                COLUMN_MRS + " TEXT" +
                ")";
        db.execSQL(CREATE_USER_DATA_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_DATA);
        onCreate(db);
    }

    public boolean addUserData(String name, String systolicPressure, String diastolicPressure,
                               String smoking, String height, String weight, String cholesterol,
                               String tos, String mrs) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_SYSTOLIC_PRESSURE, systolicPressure);
        values.put(COLUMN_DIASTOLIC_PRESSURE, diastolicPressure);
        values.put(COLUMN_SMOKING, smoking);
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_CHOLESTEROL, cholesterol);
        values.put(COLUMN_TOS, tos);
        values.put(COLUMN_MRS, mrs);

        long result = db.insert(TABLE_USER_DATA, null, values);
        return result != -1; // Returns true if inserted, false otherwise
    }

    public Cursor getAllUserData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_USER_DATA, null, null, null, null, null, null);
    }

    public boolean updateUserData(int id, String name, String systolicPressure, String diastolicPressure,
                                  String smoking, String height, String weight, String cholesterol,
                                  String tos, String mrs) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_SYSTOLIC_PRESSURE, systolicPressure);
        values.put(COLUMN_DIASTOLIC_PRESSURE, diastolicPressure);
        values.put(COLUMN_SMOKING, smoking);
        values.put(COLUMN_HEIGHT, height);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_CHOLESTEROL, cholesterol);
        values.put(COLUMN_TOS, tos);
        values.put(COLUMN_MRS, mrs);

        int updated = db.update(TABLE_USER_DATA, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return updated > 0;
    }

    public boolean deleteUserData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleted = db.delete(TABLE_USER_DATA, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        return deleted > 0;
    }

    public String[] fetchUserData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] userData = new String[9];

        Cursor cursor = db.query(
                TABLE_USER_DATA,
                new String[]{
                        COLUMN_NAME,
                        COLUMN_SYSTOLIC_PRESSURE,
                        COLUMN_DIASTOLIC_PRESSURE,
                        COLUMN_SMOKING,
                        COLUMN_HEIGHT,
                        COLUMN_WEIGHT,
                        COLUMN_CHOLESTEROL,
                        COLUMN_TOS,
                        COLUMN_MRS
                },
                COLUMN_ID + "=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            userData[0] = cursor.getString(0);
            userData[1] = cursor.getString(1);
            userData[2] = cursor.getString(2);
            userData[3] = cursor.getString(3);
            userData[4] = cursor.getString(4);
            userData[5] = cursor.getString(5);
            userData[6] = cursor.getString(6);
            userData[7] = cursor.getString(7);
            userData[8] = cursor.getString(8);
            cursor.close();
            return userData;
        } else {
            if (cursor != null) {
                cursor.close();
            }
            return null;
        }
    }

    // Get user ID by name
    public int getUserIdByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        int userId = -1;

        Cursor cursor = db.query(
                TABLE_USER_DATA,
                new String[]{COLUMN_ID},
                COLUMN_NAME + "=?",
                new String[]{name},
                null,
                null,
                null
        );

        if (cursor != null && cursor.moveToFirst()) {
            userId = cursor.getInt(0);
            cursor.close();
        }
        return userId;
    }

    public int getMaxUserId() {
        SQLiteDatabase db = this.getReadableDatabase();
        int maxUserId = -1;

        Cursor cursor = db.rawQuery("SELECT MAX(" + COLUMN_ID + ") FROM " + TABLE_USER_DATA, null);

        if (cursor != null && cursor.moveToFirst()) {
            maxUserId = cursor.getInt(0);
            cursor.close();
        }
        return maxUserId;
    }
}
