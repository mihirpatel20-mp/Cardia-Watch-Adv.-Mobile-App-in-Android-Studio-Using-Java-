package com.example.cardiawatch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class watchdata extends AppCompatActivity {

    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_watchdata);


        webView = findViewById(R.id.webview1);
        WebSettings webSettings = webView.getSettings();

        webSettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new watchdata.Callback());
        webView.loadUrl("https://airtable.com/apprnAsXyMdDIGjbb/shrt8mHtC9y0a3OWO/tblvSQoYC0c19Ck0D");

    }

    private class Callback extends WebViewClient {
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {

            return false;
        }
    }
}